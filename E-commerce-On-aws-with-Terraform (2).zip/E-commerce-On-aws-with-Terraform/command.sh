#!/bin/bash

# Update package lists and install dependencies
sudo apt update -y || echo "Failed to update package lists"
sudo apt upgrade -y || echo "Failed to upgrade packages"

# Install Docker using Snap
sudo snap install docker || { echo "Failed to install Docker"; exit 1; }

# Ensure Snap's Docker is linked correctly
if [ ! -f /usr/bin/docker ]; then
  sudo ln -s /snap/bin/docker /usr/bin/docker || { echo "Failed to link Docker binary"; exit 1; }
fi

# Install Docker Compose
DOCKER_COMPOSE_URL="https://github.com/docker/compose/releases/download/$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep -oP '"tag_name": "\K(.*)(?=")')/docker-compose-$(uname -s)-$(uname -m)"
sudo curl -L "$DOCKER_COMPOSE_URL" -o /usr/local/bin/docker-compose || { echo "Failed to download Docker Compose"; exit 1; }
sudo chmod +x /usr/local/bin/docker-compose || { echo "Failed to make Docker Compose executable"; exit 1; }

# Wait for 7 seconds to ensure Docker service is ready
echo "Waiting for Docker service to initialize..."
sleep 7

# Test Docker readiness
docker info >/dev/null 2>&1 || { echo "Docker is not ready"; exit 1; }

# Download and set up the Evershop Docker Compose file from Dropbox
sudo curl -sSL "https://www.dropbox.com/scl/fi/sawsv67f0btw3de7g213w/docker-compose.yml?rlkey=ojnbt2muja5aorijfn9h8hzxq&st=wn0vdyhv&dl=1" -o /root/docker-compose.yml || { echo "Failed to download docker-compose.yml from Dropbox"; exit 1; }

# Run the Evershop application
cd /root
sudo docker-compose up -d || { echo "Failed to run Docker Compose"; exit 1; }

echo "Waiting for Docker Compose to Create Container..."
sleep 25

# Run the user creation command inside the evershop-app container using /bin/sh
docker exec evershop-app /bin/sh -c 'npm run user:create -- --email "admin@fluidech.com" --password "adminadmin" --name "admin"' || echo "Failed to create user in evershop-app" >> /var/log/setup.log

echo "Setup completed successfully!"
