# aws_website_deploy
We will deploy a website to AWS using the terraform script in this Repository
